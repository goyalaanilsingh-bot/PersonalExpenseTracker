
package com.example.personalexpensetracker

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.personalexpensetracker.data.Expense
import com.example.personalexpensetracker.data.ExpenseDatabase
import com.example.personalexpensetracker.ui.adapter.ExpenseAdapter
import com.example.personalexpensetracker.ui.addexpense.AddExpenseFragment
import com.example.personalexpensetracker.ui.reports.MonthlyReportFragment
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var homeContent: View
    private lateinit var fragmentContainer: View

    private lateinit var tvTotalExpenses: TextView
    private lateinit var btnAddExpense: Button
    private lateinit var btnMonthlyReport: Button
    private lateinit var tvEmptyExpenses: TextView
    private lateinit var rvExpenses: RecyclerView
    private lateinit var spinnerCategoryFilter: Spinner
    private lateinit var expenseAdapter: ExpenseAdapter

    private var allExpenses: List<Expense> = emptyList()
    private var selectedCategory = "All Categories"
    private var updatingSpinner = false

    private val defaultCategories = listOf(
        "Food",
        "Transport",
        "Shopping",
        "Bills",
        "Health",
        "Education",
        "Entertainment",
        "Other"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        homeContent = findViewById(R.id.homeContent)
        fragmentContainer = findViewById(R.id.fragmentContainer)

        tvTotalExpenses = findViewById(R.id.tvTotalExpenses)
        btnAddExpense = findViewById(R.id.btnAddExpense)
        btnMonthlyReport = findViewById(R.id.btnMonthlyReport)
        tvEmptyExpenses = findViewById(R.id.tvEmptyExpenses)
        rvExpenses = findViewById(R.id.rvExpenses)
        spinnerCategoryFilter = findViewById(R.id.spinnerCategoryFilter)

        val expenseDao = ExpenseDatabase.getDatabase(this).expenseDao()

        expenseAdapter = ExpenseAdapter(
            onEditExpense = { expense ->
                openPage(AddExpenseFragment.newInstance(expense.id))
            },
            onDeleteExpense = { expense ->
                lifecycleScope.launch {
                    expenseDao.deleteExpense(expense)
                }
            }
        )

        rvExpenses.layoutManager = LinearLayoutManager(this)
        rvExpenses.adapter = expenseAdapter

        setupCategoryFilter()

        lifecycleScope.launch {
            expenseDao.getTotalExpenses().collect { total ->
                tvTotalExpenses.text =
                    "₩${"%,.0f".format(total ?: 0.0)}"
            }
        }

        lifecycleScope.launch {
            expenseDao.getAllExpenses().collect { expenses ->
                allExpenses = expenses
                updateCategoryOptions()
                applyCategoryFilter()
            }
        }

        btnAddExpense.setOnClickListener {
            openPage(AddExpenseFragment())
        }

        btnMonthlyReport.setOnClickListener {
            openPage(MonthlyReportFragment())
        }

        supportFragmentManager.addOnBackStackChangedListener {
            updateScreenVisibility()
        }

        updateScreenVisibility()
    }

    private fun openPage(fragment: Fragment) {
        homeContent.visibility = View.GONE
        fragmentContainer.visibility = View.VISIBLE

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun updateScreenVisibility() {
        val pageOpen =
            supportFragmentManager.backStackEntryCount > 0

        homeContent.visibility =
            if (pageOpen) View.GONE else View.VISIBLE

        fragmentContainer.visibility =
            if (pageOpen) View.VISIBLE else View.GONE
    }

    private fun setupCategoryFilter() {
        spinnerCategoryFilter.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (updatingSpinner) return

                    selectedCategory =
                        parent?.getItemAtPosition(position)?.toString()
                            ?: "All Categories"

                    applyCategoryFilter()
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) = Unit
            }
    }

    private fun updateCategoryOptions() {
        val categories = (
                defaultCategories + allExpenses.map { it.category }
                )
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
            .sortedBy { it.lowercase() }

        val options = listOf("All Categories") + categories
        val oldSelection = selectedCategory

        updatingSpinner = true

        spinnerCategoryFilter.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            options
        ).also { adapter ->
            adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )
        }

        val index = options.indexOfFirst {
            it.equals(oldSelection, ignoreCase = true)
        }.coerceAtLeast(0)

        spinnerCategoryFilter.setSelection(index)
        selectedCategory = options[index]
        updatingSpinner = false
    }

    private fun applyCategoryFilter() {
        val filteredExpenses =
            if (selectedCategory == "All Categories") {
                allExpenses
            } else {
                allExpenses.filter {
                    it.category.equals(
                        selectedCategory,
                        ignoreCase = true
                    )
                }
            }

        expenseAdapter.submitList(filteredExpenses)

        if (filteredExpenses.isEmpty()) {
            tvEmptyExpenses.text =
                if (allExpenses.isEmpty()) {
                    "No expenses yet. Add your first expense!"
                } else {
                    "No expenses in this category."
                }

            tvEmptyExpenses.visibility = View.VISIBLE
            rvExpenses.visibility = View.GONE
        } else {
            tvEmptyExpenses.visibility = View.GONE
            rvExpenses.visibility = View.VISIBLE
        }
    }
}
