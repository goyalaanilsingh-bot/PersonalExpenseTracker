
package com.example.personalexpensetracker.ui.addexpense

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.personalexpensetracker.R
import com.example.personalexpensetracker.data.Expense
import com.example.personalexpensetracker.data.ExpenseDatabase
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AddExpenseFragment : Fragment(R.layout.fragment_add_expense) {

    private var expenseId: Int = 0
    private var originalExpense: Expense? = null

    private lateinit var etTitle: EditText
    private lateinit var etAmount: EditText
    private lateinit var etCategory: EditText
    private lateinit var etDate: EditText
    private lateinit var etNote: EditText
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etTitle = view.findViewById(R.id.etExpenseTitle)
        etAmount = view.findViewById(R.id.etExpenseAmount)
        etCategory = view.findViewById(R.id.etExpenseCategory)
        etDate = view.findViewById(R.id.etExpenseDate)
        etNote = view.findViewById(R.id.etExpenseNote)
        btnSave = view.findViewById(R.id.btnSaveExpense)
        btnCancel = view.findViewById(R.id.btnCancelExpense)

        expenseId = arguments?.getInt(ARG_EXPENSE_ID, 0) ?: 0

        if (expenseId != 0) {
            btnSave.text = "Update Expense"
            loadExpense()
        } else {
            etDate.setText(
                SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    .format(Date())
            )
        }

        btnSave.setOnClickListener {
            saveExpense()
        }

        btnCancel.setOnClickListener {
            parentFragmentManager.popBackStack()
        }
    }

    private fun loadExpense() {
        val dao = ExpenseDatabase.getDatabase(requireContext()).expenseDao()

        viewLifecycleOwner.lifecycleScope.launch {
            val expense = dao.getExpenseById(expenseId)

            if (expense == null) {
                Toast.makeText(
                    requireContext(),
                    "Expense not found",
                    Toast.LENGTH_SHORT
                ).show()
                parentFragmentManager.popBackStack()
                return@launch
            }

            originalExpense = expense

            etTitle.setText(expense.title)
            etAmount.setText(expense.amount.toString())
            etCategory.setText(expense.category)
            etDate.setText(
                SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    .format(Date(expense.date))
            )
            etNote.setText(expense.note)
        }
    }

    private fun saveExpense() {
        val title = etTitle.text.toString().trim()
        val amountText = etAmount.text.toString().trim()
        val category = etCategory.text.toString().trim()
        val dateText = etDate.text.toString().trim()
        val note = etNote.text.toString().trim()

        if (title.isEmpty() ||
            amountText.isEmpty() ||
            category.isEmpty() ||
            dateText.isEmpty()
        ) {
            Toast.makeText(
                requireContext(),
                "Please fill in all required fields",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val amount = amountText.toDoubleOrNull()

        if (amount == null || !amount.isFinite() || amount <= 0) {
            etAmount.error = "Enter a valid amount greater than zero"
            return
        }

        val parsedDate = try {
            SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                isLenient = false
            }.parse(dateText)
        } catch (_: Exception) {
            null
        }

        if (parsedDate == null) {
            etDate.error = "Use the format yyyy-MM-dd"
            return
        }

        val dao = ExpenseDatabase.getDatabase(requireContext()).expenseDao()

        viewLifecycleOwner.lifecycleScope.launch {
            if (expenseId != 0) {
                val existing = originalExpense

                if (existing == null) {
                    Toast.makeText(
                        requireContext(),
                        "Expense is still loading. Please try again.",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@launch
                }

                dao.updateExpense(
                    existing.copy(
                        title = title,
                        amount = amount,
                        category = category,
                        date = parsedDate.time,
                        note = note
                    )
                )

                Toast.makeText(
                    requireContext(),
                    "Expense updated",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                dao.insertExpense(
                    Expense(
                        title = title,
                        amount = amount,
                        category = category,
                        date = parsedDate.time,
                        note = note
                    )
                )

                Toast.makeText(
                    requireContext(),
                    "Expense added",
                    Toast.LENGTH_SHORT
                ).show()
            }

            parentFragmentManager.popBackStack()
        }
    }

    companion object {
        private const val ARG_EXPENSE_ID = "expense_id"

        fun newInstance(expenseId: Int): AddExpenseFragment {
            return AddExpenseFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_EXPENSE_ID, expenseId)
                }
            }
        }
    }
}
