
package com.example.personalexpensetracker.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.personalexpensetracker.R
import com.example.personalexpensetracker.data.Expense
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExpenseAdapter(
    private val onEditExpense: (Expense) -> Unit,
    private val onDeleteExpense: (Expense) -> Unit
) : RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    private var expenses: List<Expense> = emptyList()

    class ExpenseViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val title: TextView =
            itemView.findViewById(R.id.tvExpenseTitle)

        val amount: TextView =
            itemView.findViewById(R.id.tvExpenseAmount)

        val details: TextView =
            itemView.findViewById(R.id.tvExpenseDetails)

        val note: TextView =
            itemView.findViewById(R.id.tvExpenseNote)

        val editButton: Button =
            itemView.findViewById(R.id.btnEditExpense)

        val deleteButton: Button =
            itemView.findViewById(R.id.btnDeleteExpense)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ExpenseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense, parent, false)

        return ExpenseViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ExpenseViewHolder,
        position: Int
    ) {
        val expense = expenses[position]

        holder.title.text = expense.title
        holder.amount.text = "₩${"%,.0f".format(expense.amount)}"

        val dateText = SimpleDateFormat(
            "yyyy-MM-dd",
            Locale.US
        ).format(Date(expense.date))

        holder.details.text = "${expense.category} • $dateText"

        holder.note.text = expense.note
        holder.note.visibility =
            if (expense.note.isBlank()) View.GONE else View.VISIBLE

        holder.editButton.setOnClickListener {
            onEditExpense(expense)
        }

        holder.deleteButton.setOnClickListener {
            AlertDialog.Builder(holder.itemView.context)
                .setTitle("Delete expense?")
                .setMessage("Do you want to delete \"${expense.title}\"?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ ->
                    onDeleteExpense(expense)
                }
                .show()
        }
    }

    override fun getItemCount(): Int = expenses.size

    fun submitList(newExpenses: List<Expense>) {
        expenses = newExpenses
        notifyDataSetChanged()
    }
}
