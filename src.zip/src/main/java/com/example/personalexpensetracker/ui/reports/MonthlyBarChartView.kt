
package com.example.personalexpensetracker.ui.reports

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.text.NumberFormat
import java.util.Locale

data class MonthlySpending(
    val label: String,
    val amount: Double
)

class MonthlyBarChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF3977D5.toInt()
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF555555.toInt()
        textSize = 12f * resources.displayMetrics.scaledDensity
        textAlign = Paint.Align.CENTER
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCCCCC.toInt()
        strokeWidth = resources.displayMetrics.density
    }

    private val moneyFormat = NumberFormat.getNumberInstance(Locale.US)
    private var monthlyData: List<MonthlySpending> = emptyList()

    fun setData(data: List<MonthlySpending>) {
        monthlyData = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (monthlyData.isEmpty()) return

        val density = resources.displayMetrics.density
        val left = 12f * density
        val right = width - 12f * density
        val top = 20f * density
        val bottom = height - 38f * density
        val chartHeight = bottom - top

        if (chartHeight <= 0 || right <= left) return

        val maxAmount = monthlyData.maxOf { it.amount }
            .coerceAtLeast(1.0)

        canvas.drawLine(left, bottom, right, bottom, linePaint)

        val slotWidth =
            (right - left) / monthlyData.size.toFloat()

        val barWidth = slotWidth * 0.55f
        val labelPaint = Paint(textPaint).apply {
            textSize = 11f * density
        }

        monthlyData.forEachIndexed { index, item ->
            val barHeight =
                (item.amount / maxAmount).toFloat() * chartHeight

            val centerX = left + slotWidth * (index + 0.5f)
            val barTop = bottom - barHeight

            if (item.amount > 0) {
                canvas.drawRoundRect(
                    RectF(
                        centerX - barWidth / 2,
                        barTop,
                        centerX + barWidth / 2,
                        bottom
                    ),
                    5f * density,
                    5f * density,
                    barPaint
                )
            }

            val labelY = height - 12f * density
            canvas.drawText(
                item.label,
                centerX,
                labelY,
                labelPaint
            )
        }
    }
}
