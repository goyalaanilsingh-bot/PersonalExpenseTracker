
package com.example.personalexpensetracker.ui.reports

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.personalexpensetracker.R
import com.example.personalexpensetracker.data.ExpenseDatabase
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MonthlyReportFragment :
    Fragment(R.layout.fragment_monthly_report) {

    private lateinit var tvReportRange: TextView
    private lateinit var tvReportTotal: TextView
    private lateinit var tvMonthlyBreakdown: TextView
    private lateinit var monthlyBarChart: MonthlyBarChartView
    private lateinit var btnCloseReport: Button

    private val monthKeyFormat =
        SimpleDateFormat("yyyy-MM", Locale.US)

    private val monthLabelFormat =
        SimpleDateFormat("MMM yy", Locale.US)

    private val moneyFormat =
        java.text.NumberFormat.getNumberInstance(Locale.US)

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        tvReportRange = view.findViewById(R.id.tvReportRange)
        tvReportTotal = view.findViewById(R.id.tvReportTotal)
        tvMonthlyBreakdown =
            view.findViewById(R.id.tvMonthlyBreakdown)
        monthlyBarChart =
            view.findViewById(R.id.monthlyBarChart)
        btnCloseReport = view.findViewById(R.id.btnCloseReport)

        btnCloseReport.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        val dao =
            ExpenseDatabase.getDatabase(requireContext()).expenseDao()

        viewLifecycleOwner.lifecycleScope.launch {
            dao.getAllExpenses().collect { expenses ->

                val calendar = Calendar.getInstance()
                calendar.set(Calendar.DAY_OF_MONTH, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)

                val monthStarts = mutableListOf<Long>()

                repeat(6) {
                    monthStarts.add(calendar.timeInMillis)
                    calendar.add(Calendar.MONTH, -1)
                }

                monthStarts.reverse()

                val monthKeys = monthStarts.map { timestamp ->
                    monthKeyFormat.format(Date(timestamp))
                }

                val monthLabels = monthStarts.map { timestamp ->
                    monthLabelFormat.format(Date(timestamp))
                }

                val totalsByMonth = expenses
                    .groupBy { expense ->
                        monthKeyFormat.format(Date(expense.date))
                    }
                    .mapValues { (_, monthExpenses) ->
                        monthExpenses.sumOf { it.amount }
                    }

                val reportData = monthKeys.indices.map { index ->
                    MonthlySpending(
                        label = monthLabels[index],
                        amount = totalsByMonth[monthKeys[index]] ?: 0.0
                    )
                }

                val periodTotal = reportData.sumOf { it.amount }

                tvReportRange.text =
                    "Last 6 months: ${monthLabels.first()} – ${monthLabels.last()}"

                tvReportTotal.text =
                    "₩${moneyFormat.format(periodTotal)}"

                monthlyBarChart.setData(reportData)

                tvMonthlyBreakdown.text = reportData
                    .asReversed()
                    .joinToString("\n\n") { month ->
                        "${month.label}: ₩${moneyFormat.format(month.amount)}"
                    }
            }
        }
    }
}
